//
//  GenreController.swift
//  AssignmentNine
//
//  Created by Nagarjun Mallesh on 24/03/24.
//

import UIKit

class GenreController: UIViewController {
    
    var nextId : Int = 1
    
    public func alertMessage(_ message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title:"Ok", style: UIAlertAction.Style.default, handler:nil))
        self.present(alert, animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet var genreNameTxt: UITextField!
    @IBOutlet var genreIdTxt: UITextField!
    
    @IBAction func updateGenre(_ sender: Any) {
        
        guard let genreStringId = genreIdTxt.text, let genreName = genreNameTxt.text, !genreStringId.isEmpty, !genreName.isEmpty, let genreId = Int(genreStringId) else {
            alertMessage("Please enter the correct genre information")
            return
        }
        
        GenreService.shared.updateGenre(genreId: genreId, newGenreName: genreName)
        alertMessage("Genre Updated Successfully..")
        genreIdTxt.text = ""
        genreNameTxt.text = ""
        
    }
    
    @IBAction func addGenreBtn(_ sender: Any) {
        
        guard let name = genreNameTxt.text, !name.isEmpty else {
            alertMessage("Enter the details correctly")
            return
        }
        
        let genre = Genre(id: nextId, name: name)
        GenreService.shared.addGenre(genre)
        nextId += 1
        genreNameTxt.text = ""
        alertMessage("The genre is created successfully")
        
        
    }
    
    @IBAction func deleteGenre(_ sender: Any) {
        
        guard let genreStringId = genreIdTxt.text, !genreStringId.isEmpty, let genreId = Int(genreStringId) else {
            alertMessage("Please enter the correct genre ID")
            return
        }
        
        if GenreService.shared.genreExists(genreId: genreId) {
            let songCount = SongService.shared.checkSongsInGenre(genreId: genreId)
            if  songCount > 0 {
                alertMessage("Genres cannot be deleted as there are Songs under the following genre")
            }else {
                if GenreService.shared.genreDelete(genreId: genreId) {
                    alertMessage("Genre Deleted Successfully")
                } else {
                    alertMessage("Genre could not be deleted..")
                }
            }
        }else {
            alertMessage("Genre not found...")
        }
        genreIdTxt.text = ""
        genreNameTxt.text = ""
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
