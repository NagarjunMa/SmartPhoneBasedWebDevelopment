//
//  ViewController.swift
//  AssignmentNine
//
//  Created by Nagarjun Mallesh on 21/03/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

